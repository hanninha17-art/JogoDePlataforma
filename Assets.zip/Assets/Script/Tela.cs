using UnityEngine;
using UnityEngine.SceneManagement;

public class Tela : MonoBehaviour
{
    public void IniciarJogo()

    {
        SceneManager.LoadScene("SampleScene");
    }

    public void SairDoJogo(){
        Application.Quit();
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
