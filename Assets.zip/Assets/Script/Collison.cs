using UnityEngine;
using UnityEngine.SceneManagement;
public class Collison : MonoBehaviour


{
    private int contador = 0;
    void OnCollisionEnter2D(Collision2D collision) {
        if (collision.gameObject.CompareTag("Inimigo")) {
            SceneManager.LoadScene("fimdejogo");
            Destroy(gameObject);
        }

        if (collision.gameObject.CompareTag("Item")) {
            Destroy(collision.gameObject);
            contador = contador + 100;
        }
        Debug.Log(collision.gameObject.tag);
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
     Debug.Log(contador);   
    }
}
