using UnityEngine;

public class Movimento : MonoBehaviour
{
     public float velocidade;
     public float pulo = 20;
     private Rigidbody2D rb;
        // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        
    }

    // Update is called once per frame
    void Update()
    {
       if (Input.GetKeyDown(KeyCode.D)){
       rb.linearVelocity = new Vector2(velocidade, rb.linearVelocity.y);
       }
       if (Input.GetKeyDown(KeyCode.A)) {
        rb.linearVelocity = new Vector2(-velocidade, rb.linearVelocity.y);
       }
       if (Input.GetKeyDown(KeyCode.Space)) {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, pulo);
       }
}
}
